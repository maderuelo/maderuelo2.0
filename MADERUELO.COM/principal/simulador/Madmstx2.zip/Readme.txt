PHOTOREALISTIC SCENERY OF MADERUELO VILLAGE (NORTH SEGOVIA) FOR FS2002/4 CREATED BY ALBERTO CRIST�BAL GRANDA Copyrights 2004

REMARKS

The photorealistic scenery of MADERUELO, is over a Mesh created by the SMG Spain Mesh Group 
http://www.simuvuelo.org/pags06/smg.htm that represent the North of Segovia
The Mesh has a great quality and it has the most exact elevations existing all over the world. 
The MADERUELO (MADE.BGL) Mesh is a LOD 10 mesh.
the area includes a lake wich I hope soon will be landable with anphibian planes
you can find more information about the MEDIEVAL TOWN OF MADERUELO in: 

				http://www.maderuelo.com

INSTALATION

You just need to unzipp the files in a folder call Maderuelo and add scenery in FS2002/4
Once you have got installed the scenery you can fly from Madrid Barajas 
or you can place the plane in 41� 31.10�N 3� 32.78�W


Thanks to JULIO ESTEFAN�A ESTEFAN�A, your help and your cooperation.

OTHER SCENERIES MADE BY JULIO ESTEFAN�A ESTEFAN�A

PICOS DE EUROPA Search in files of AVSIM : picos_de_europa.zip
LA RIOJA Search in files of AVSIM : escenario_de_la_rioja001.zip till the escenario_de_la_rioja008.zip 
ans also the escenario_de_la_rioja.exe
SCENARY OF VIZCAYA (only for FS2000) Search in files of AVSIM:  vizcayacenter.zip and vizcayawest.zip
MESH OF PIRINEES Search in files of AVSIM:  pirineos.zip

My address is:

ALBERTO CRIST�BAL GRANDA
C/ VILLA DE MAR�N 17 6� A
28029 MADRID
SPAIN
acristobal@maderuelo.com

Enjoy